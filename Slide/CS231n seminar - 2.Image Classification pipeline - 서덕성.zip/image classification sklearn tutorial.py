# -*- coding: utf-8 -*-
"""
Created on Tue Jan 10 16:38:04 2017

@author: deokseong
"""


# Import packages
import matplotlib.pyplot as plt
from sklearn import datasets
import pandas as pd


# The hand-written digits dataset (8x8 image)
digits = datasets.load_digits()

# Target
images_and_labels = list(zip(digits.images, digits.target))

# Visualization of 4 images
for index, (image, label) in enumerate(images_and_labels[:4]):
    plt.subplot(2, 4, index + 1) # 2 x 4의 subplot 위치를 할당하고, 각 image를 할당해서 그림
    plt.axis('off') #축 없음
    plt.imshow(image, cmap=plt.cm.gray_r, interpolation='nearest') #image 파일을 시각화 하는 함수. 타입을 흑백으로.
    plt.title('Training: %i' % label) #title 설정


# need to flatten the image to apply a image analysis
n_samples = len(digits.images)
data = digits.images.reshape((n_samples, -1)) # vector
data = list(zip(data, digits.target))
data = pd.DataFrame(data)



# K-NN classification
import numpy as np
import matplotlib.pyplot as plt
import math

class NearestNeighbor:
    def __init__(self):
        pass
    
    def train(self, X, y):
        """X : N x D training data set, Y : N x 1 label"""
        #the nearest neighbor classifier simply remembers all the training data
        self.Xtr = X
        self.ytr = y
    
    def predict(self, X):
        """X : M x D test data set"""        
        num_test = X.shape[0] #행 개수(M)
        Ypred = np.zeros(num_test, dtype=self.ytr.dtype) #먼저 0으로 가득 채워둠
    
        for i in np.arange(len(X)): #모든 test data에 대해
            print(i, '\n')        

            distance = np.zeros(len(self.Xtr))
            for j in np.arange(len(self.Xtr)):
                distances = np.sum(np.abs(self.Xtr.iloc[j] - X.iloc[i]), axis=0) #trining data와 L1-norm을 구함
                distance[j] = distances
        
            min_index = np.argmin(distance) #가장 가까운 1-NN의 index를 구함
            Ypred[i] = self.ytr.iloc[min_index] #가장 가까운 이웃의 label을 적용
            
        return(Ypred)

#training / test split
# Randomly shuffle the index of nba.
random_indices = np.random.permutation(data.index)
# Set a cutoff for how many items we want in the test set (in this case 1/3 of the items)
test_cutoff = math.floor(len(data)/3)
# Generate the test set by taking the first 1/3 of the randomly shuffled indices.
ts = data.loc[random_indices[1:test_cutoff]]
# Generate the train set with the rest of the data.
tr = data.loc[random_indices[test_cutoff:]]

#Object
nn = NearestNeighbor()

#training (just save)
nn.train(tr.ix[:, 0], tr.ix[:, 1])
Ypred = nn.predict(ts.ix[:, 0])
